package com.example.assignment4;

public class Textbook {
    private double price;
    private String title;
    private String seller;

    Textbook(double p, String t, String s) {
        price = p;
        title = t;
        seller = s;
    }
    public double getPrice() {
        return price;
    }
    public String getTitle() {
        return title;
    }
    public String getSeller() {
        return seller;
    }
    public void setPrice(double p ) {
        price = p;
    }
    public void setTitle(String t ) {
        title = t;
    }public void setSeller(String s ) {
        seller = s;
    }

}
